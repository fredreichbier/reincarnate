ooc-yajl
========

ooc-yajl is an `ooc <http://ooc-lang.org>`_ binding to `yet another json library <http://lloyd.github.com/yajl/>`_ by `lloyd <http://github.com/lloyd>`_ - thanks for the great library!

Currently, it is able to read json files, writing will follow.

ooc-yajl is licensed under the MIT license (see LICENSE for details)
